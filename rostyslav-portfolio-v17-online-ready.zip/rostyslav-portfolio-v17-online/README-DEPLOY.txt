ROSTYSLAV PORTFOLIO V17
Online-ready static build.
Upload the CONTENTS of this folder (index.html + assets folder) to the web root.

V17 behavior fixes:
- Opening a video no longer repositions the page behind the modal.
- Closing a video leaves the user at exactly the same scroll position.
- Hero video cover keeps playing while any part of the hero remains visible.
- Hero cover resets to 0 only after the hero is fully left.
- Initial hero autoplay remains delayed by ~2.2 seconds.
